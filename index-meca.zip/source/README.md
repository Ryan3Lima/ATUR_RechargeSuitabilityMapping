## A Quarto Manuscript and Code

This project is intended to describe and advocate for more research into Opportunistic Recharge Enhancement. This project is part of ATUR, the Arizona Tri-University Recharge Project


This is a template repo for generating a manuscript from Quarto that accompanies the tutorial at: [Quarto Manuscripts: Jupyter Lab](https://quarto.org/docs/manuscripts/authoring/jupyterlab.html)




